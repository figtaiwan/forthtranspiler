var runtimecode=
["var stack=[], _out='';"
,"var runtime={stack:stack,out:_out};"]